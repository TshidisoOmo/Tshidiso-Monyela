
# Tshidiso Monyela — Professional Portfolio

A responsive personal portfolio website built with HTML5, CSS3 and JavaScript.

## Sections
- Home
- About Me
- Skills
- Projects
- Education
- Certifications
- Experience
- Contact
- Downloadable CV

## Portfolio projects
1. Student Resource Hub
2. Personal Expense Tracker
3. Task & Information Dashboard

## Run locally
Open `index.html` in a browser, or use VS Code Live Server.

## Deployment
This project can be deployed to GitHub Pages, Netlify or Vercel. For GitHub Pages, upload the repository contents and enable Pages from the repository's Settings > Pages section.

## AI-assisted development
AI was used as a development assistant for planning, content structuring, responsive UI ideas and code drafting. The final code should be reviewed and understood by the student before submission.


## Career goal
To secure an internship or entry-level opportunity in information technology, information management or a related digital field where I can apply my Information Sciences knowledge, develop practical technical skills and contribute to meaningful digital solutions.

## Project details
### 1. Student Resource Hub
A searchable and filterable study-resource interface. It demonstrates DOM manipulation, filtering, semantic HTML and responsive design.

### 2. Personal Expense Tracker
A simple browser-based finance tracker for recording income and expenses. It demonstrates JavaScript calculations and browser localStorage.

### 3. Task & Information Dashboard
An interactive task-management dashboard. It demonstrates event handling, state persistence with localStorage and responsive UI.

These are **student portfolio projects created for demonstration and learning** and should be described as such when presenting the work.
